USE `lzx_ci_sample`;
SET NAMES utf8;

BEGIN;
INSERT INTO `user` VALUES (1, '郭靖', 'MALE', '18600001001', 'abcdefg');
INSERT INTO `user` VALUES (2, '黄蓉', 'FEMALE', '18600001002', 'abcdefg');

COMMIT;